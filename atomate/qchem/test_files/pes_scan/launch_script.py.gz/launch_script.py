import copy
import random

from pymatgen.core.structure import Molecule
from pymatgen.io.qchem.outputs import QCOutput

from fireworks import LaunchPad, Workflow

from atomate.vasp.powerups import add_tags
from atomate.qchem.database import QChemCalcDb
from atomate.qchem.fireworks.core import PESScanFW

params = {"overwrite_inputs": {"rem": {"thresh": "14",
                                       "basis": "def2-svp",
                                       "method": "pbe",
                                       "scf_algorithm": "diis"}}}

calc_db = QChemCalcDb.from_db_file("/global/homes/e/ewcss/cori/config/db.json")
lp = LaunchPad.from_file("/global/homes/e/ewcss/cori/config/sam_launchpad.yaml")

mol = Molecule.from_file("co3.xyz")
mol.set_charge_and_spin(-2)

scan_variables = {"stre": ["1 2 1.30 1.40 0.02"]}

pes_scan_fw = PESScanFW(molecule=mol,
                        name="pes_scan_test",
                        qchem_cmd="qchem",
                        multimode="openmp",
                        max_cores=32,
                        qchem_input_params=params,
                        scan_variables=scan_variables,
                        db_file="/global/homes/e/ewcss/cori/config/db.json")
wf = Workflow([pes_scan_fw], name="pes scan test")
wf = add_tags(wf, {"class": "pes_test"})
lp.add_wf(wf)

